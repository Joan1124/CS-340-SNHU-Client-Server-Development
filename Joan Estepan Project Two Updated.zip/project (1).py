from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps, loads
import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.username=username
        self.password=password
        self.client = MongoClient('mongodb://%s:%s@localhost:53891/?authSource=AAC' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary
            print("success")
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Create method to implement the R in CRUD
    def read(self, search):
        
        if search is not None:
           
             searchResult = self.database.animals.find(search,{"_id":False})
  
             return searchResult
            # Checks to see if the data is empty and returns exception
        else:
            exception = "Nothing to search, because parameter is empty"
            return exception
        
#creat method to implement the U (update) in CRUD
    def update(self, data, update_data):
        if data is not None:
            self.database.animals.update_many(data, update_data)
            
            result = self.database.animals.find(data)
            my_list = list(result)
            y = dumps(my_list, indent = 2)           
            print('success')
            return y
            # Checks to see if the data is empty and returns exception
        else:
            exception = "Nothing to update, because parameter is empty"
            return exception
        
#create method to implemenmt the D in CRUD (Delete)
    def delete(self, delete):
        
        if delete is not None:
            result = self.database.animals.delete_many(delete)
          
            return result
            # Checks to see if the data is empty and returns exception
        else:
            exception = "Nothing to delete, because parameter is empty"
            return exception

        